package com.example.primerApp.clases;
public class Pais {
    int idPais;
    String pais;


    public Pais() {
    }

    public Pais(int idPais, String pais) {
        this.idPais = idPais;
        this.pais = pais;
    }

    public int getIdPais() {
        return this.idPais;
    }

    public void setIdPais(int idPais) {
        this.idPais = idPais;
    }

    public String getPais() {
        return this.pais;
    }

    public void setPais(String pais) {
        this.pais = pais;
    }




}
